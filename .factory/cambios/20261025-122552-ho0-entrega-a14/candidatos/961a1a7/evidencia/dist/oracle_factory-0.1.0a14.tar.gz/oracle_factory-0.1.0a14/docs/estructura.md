# Dónde está cada cosa

Un proyecto Factory reparte lo que guarda entre cuatro lugares. Saber cuál es cuál evita inventar nombres: para el último caso hay comandos que lo dicen (`oracle-factory donde`, `ruta` y `buscar`, más abajo).

```text
proyecto/
  .factory/                           # lo que Factory produce; versionada, salvo local/
    LEEME.md                          # explica la carpeta; existe para que Git la versione aunque esté vacía
    config.json                       # configuración del proyecto: modo por defecto, tipos obligatorios, alias de capacidades, revisores, carpeta del proyecto Oracle y escalares
    specs/<capacidad>.json            # índice de la spec consolidada: de qué cambio viene cada requisito y qué reemplazó
    resumen.md                        # el estado actual en una lectura: se genera, no se edita a mano
    cambios/<ID>/                     # un cambio
      factory.json                    #   su estado: fase, decisiones, eventos
      review.md                       #   la revisión libre, si la hubo
      oracle-veredicto.txt            #   el último veredicto de Oracle
      candidatos/<sha7>/              # todo lo que se produjo sobre ese commit
        evidencia/                    #   salida del sensor, pruebas, cobertura de Oracle
        clue/                         #   paquete de contexto de Clue
        revision/                     #   informes, decisiones y triage de la revisión
    local/                            # de esta máquina; Git la ignora
      revisiones/<sha7>/              #   checkouts estables para Clue
      revisiones/<sha7>-<revisor>-<n>/ #   clon aparte de cada pedido de revisión
      revisores/<sha7>-<revisor>-<n>/  #   pedido, salida e informe de cada revisor
      rag/indice.sqlite               #   el índice de preguntar (se rehace solo)
  openspec/changes/<ID>/              # el acuerdo humano, visible: propuesta, spec, diseño y plan
  openspec/specs/<capacidad>/spec.md  # lo vigente de cada capacidad: se genera al cerrar cada cambio
  tareas/                             # de Oracle Task: la tarea de cada cambio (TAREA.md)
  requisitos/  catalogos/  oracle.json    # de Oracle: requisitos, medidas y configuración
  kb/                                 # el vault: notas generadas del registro (cambios/, requisitos/, README.md),
                                      #   notas de personas (notas/) y las preguntas de oro de preguntar
  AGENTS.md  CLAUDE.md                # la guía para agentes: un bloque generado por Factory y lo que escribe el proyecto
  .gitattributes                      # los drivers de merge de Factory: el registro se une, lo generado se rehace
```

## Quién es dueño de qué

| Carpeta | Dueño | Qué contiene |
|---|---|---|
| `.factory/` | Factory | El estado de cada cambio, la configuración, los índices de las specs consolidadas (`specs/`), lo que se produce sobre un candidato y lo propio de cada máquina |
| `openspec/changes/<ID>/` | OpenSpec | Sólo el acuerdo: `proposal.md`, `design.md`, `tasks.md` y `specs/` |
| `openspec/specs/<capacidad>/` | Factory (formato OpenSpec) | La spec consolidada: los requisitos vigentes de la capacidad. Se genera; no se edita a mano |
| `tareas/` | Oracle Task | La tarea de cada cambio, con sus notas |
| `requisitos/`, `catalogos/`, `oracle.json` | Oracle | Los requisitos importados, las medidas y la configuración |
| `kb/` | Factory y las personas | `cambios/`, `requisitos/` y `README.md` se generan del registro (no se editan a mano); `notas/` es de las personas, con sus fuentes ([conocimiento](conocimiento.md)) |
| `AGENTS.md`, `CLAUDE.md` | El proyecto, con un bloque de Factory | El bloque marcado lo escribe `oracle-factory agentes` ([agentes](agentes.md)); el resto es del proyecto |

El acuerdo humano queda a la vista en `openspec/changes/`, no escondido: es lo que se lee para saber qué se construye, y si cambia, invalida la revisión.

## Lo versionado y lo local

- **`.factory/` se versiona**: es lo que comparten las personas. Lo que Factory escribe ahí lleva rutas relativas al proyecto, nunca la ruta de una máquina, para que un clon en otro lugar lo encuentre.
- **`.factory/local/` no se versiona**: `init` agrega `.factory/local/` al `.gitignore`. Ahí van los clones de revisión y el índice de `preguntar`, que son de cada máquina. Si esa carpeta no estuviera ignorada, Git ofrecería esos checkouts como directorios sin seguimiento.
- `local/revisiones/` guarda los checkouts estables y el clon aparte de cada pedido (`<sha7>-<revisor>-<n>/`).
- `local/revisores/` guarda el pedido, la salida y el informe de cada revisor (`<sha7>-<revisor>-<n>/`).
- **Git no versiona carpetas vacías**, así que `init` deja `.factory/LEEME.md`, que explica la carpeta, y un `.gitkeep` en cada carpeta vacía que crea: un clon recién hecho puede trabajar.
- La huella de archivos del producto excluye `.factory/` entera, como ya excluye `tareas/`, y las specs consolidadas que genera Factory (ver más abajo): agregar evidencia o un paquete de Clue no invalida una revisión. Cambiar el acuerdo, el código o las medidas sí.

## Una carpeta por candidato

Un candidato es un commit sobre el que se produjo algo. Su carpeta es `.factory/cambios/<ID>/candidatos/<sha7>/`, se llama como el SHA de 7 caracteres del commit, y agrupa lo que se produjo en él:

```fish
oracle-factory ruta ID evidencia      # .../.factory/cambios/ID/candidatos/<sha7>/evidencia
oracle-factory ruta ID clue           # .../candidatos/<sha7>/clue
oracle-factory ruta ID revision       # .../candidatos/<sha7>/revision
oracle-factory ruta ID checkout       # .../.factory/local/revisiones/<sha7>
```

`ruta` imprime la ruta del **candidato vigente** —el mismo que usan `pedir-revision` y `juzgar`: el commit con carpeta propia más cercano a HEAD, si el producto no cambió desde él— o la de HEAD si no hay ninguno, y **no crea nada**. Así, commitear informes o evidencia no abre un candidato nuevo: la evidencia siguiente va a la misma carpeta. Se usa así:

```fish
python examples/notas/sensor.py --salida (oracle-factory ruta ID evidencia)/hechos.json
git worktree add --detach (oracle-factory ruta ID checkout) HEAD
```

Lo que se guarda ahí, Factory lo usa:

- **`juzgar ID` sin `--con`** toma `evidencia/hechos.json` del candidato vigente: el commit con carpeta propia más cercano a HEAD, siempre que el producto no haya cambiado desde él (guardar la evidencia en un commit posterior no lo cambia). Si no lo encuentra, dice la ruta donde lo espera.
- **`revision-preparar ID`** lee los informes de los revisores en `revision/*.json` (formato de Oracle Clue), la evidencia (`evidencia/resultado.json`) y el paquete de Clue (`clue/*.json`), y completa el informe guiado: hallazgos con ubicación y lo que dijo cada revisor, comprobaciones, límites y archivos del candidato. Las decisiones quedan sin estado: las toma la persona. Cada informe se valida con Oracle Clue, que viene con Factory, contra su paquete y su checkout; si faltan o Clue lo rechaza, no se usa. Un informe de otro candidato, ilegible o que Clue rechaza se avisa y no se usa.
- **Los paquetes de Clue no se versionan** (`init` agrega `.factory/cambios/*/candidatos/*/clue/` al `.gitignore`): son de cada máquina, como los checkouts. Pesan cientos de KB —más de lo que Clue acepta en un diff— y guardan la ruta absoluta del checkout que revisaron. Sí se versionan los informes de los revisores (`revision/`), que son chicos y son lo que se decide.

## Encontrar las cosas

| Comando | Para qué |
|---|---|
| `oracle-factory donde ID` | Lista cada artefacto del cambio con su ruta, si existe y qué gate respalda |
| `oracle-factory donde ID --candidato SHA` | Lo mismo, limitado a ese candidato |
| `oracle-factory donde ID --json` | Lo mismo como JSON (ver [Salidas en JSON](#salidas-en-json)) |
| `oracle-factory buscar TEXTO` | Busca en propuestas, specs, requisitos, tareas y registros; muestra ruta, línea y cambio |
| `oracle-factory resumen` | Escribe `.factory/resumen.md`: el estado actual en una lectura; `--verificar` dice si quedó viejo |
| `oracle-factory listar --abiertos` | Los cambios abiertos (también `--cerrados` y `--fase FASE`) |

Todos son de sólo lectura. Un artefacto que el registro menciona pero ya no existe aparece como **AUSENTE**, no se oculta; un valor del registro que no es una ruta de texto aparece como **no válido**. `buscar` compara sin distinguir mayúsculas ni formas equivalentes (`Straße` y `STRASSE`), y avisa cuántos archivos omitió por superar 1 MB.

## Desde cualquier carpeta

Como Git, los comandos buscan `.factory/` subiendo desde la carpeta actual, y usan el proyecto que encuentren. Si lo encontraron arriba, lo dicen por la salida de error. `--proyecto` manda siempre; sin `.factory/` en ningún ancestro, se usa la carpeta actual como hasta ahora. `init` crea `.factory/` en la carpeta donde se ejecuta, y avisa si esa carpeta está dentro de otro proyecto.

Tres límites protegen de usar el proyecto equivocado:

- Un **proyecto anterior sin `.factory/`** (el que tiene `oracle.json` y `openspec/changes/`) es una frontera: no hereda el proyecto de afuera.
- **Tu carpeta personal nunca es la raíz.** Otras herramientas usan `~/.factory/` y no debe tomarse por un proyecto.
- Un **enlace simbólico** llamado `.factory` no cuenta como marcador.

## Los cambios anteriores

Los cambios creados antes de esta estructura tienen su evidencia en carpetas con otros nombres (`evidencia-mapeo`, `revision-pendiente`, `contexto-clue-<sha>.json`…). **No se mueven.** `donde` las lista como *históricas*: son evidencia atada a hashes y, en el caso de los paquetes de Clue, a la ruta del checkout que revisaron.

## Lo vigente de cada capacidad

Cada cambio trae una spec *delta*: lo que agrega (`ADDED`), modifica (`MODIFIED`) o quita (`REMOVED`); sin encabezados, todo cuenta como agregado. Al cerrar el cambio, Factory la fusiona en `openspec/specs/<capacidad>/spec.md`, que queda con los requisitos vigentes y, en cada uno, el cambio y el requisito de Oracle de los que viene. Para saber qué hace el sistema hoy se lee esa spec, no todas las propuestas.

- **Un conflicto no se resuelve solo:** agregar un requisito que ya existe, modificar o quitar uno que no existe, repetir un nombre en la spec del cambio o usar `RENAMED` rechaza el cierre antes de preguntar y nombra el requisito. Para resolverlo se corrige la spec del cambio: `MODIFIED` para cambiar un requisito que ya existe, `REMOVED` para darlo de baja, y para renombrarlo se quita y se agrega con el nombre nuevo. Corregir la spec cambia el acuerdo: hay que volver a aceptarla (`aprobar-spec`), reimportar, decidir las medidas y renovar la revisión y el juicio antes de cerrar.
- **Una spec consolidada editada a mano no se pisa:** si `openspec/specs/<capacidad>/spec.md` no es la que generó Factory, cerrar o archivar un cambio de esa capacidad se rechaza antes de preguntar. Se restaura con `git restore openspec/specs/<capacidad>/spec.md` y se vuelve a intentar (moverla no alcanza: una vez que existe su índice, Factory espera encontrarla); lo que se quería cambiar entra por la spec de un cambio.
- **Nada de lo cerrado se mueve:** a diferencia de OpenSpec, la carpeta del cambio queda en `openspec/changes/<ID>/` y sus requisitos de Oracle no se reimportan. `estado` de un cambio archivado dice cuáles de sus requisitos siguen vigentes y cuáles reemplazó otro cambio.
- **El proyecto Oracle en una carpeta:** si el repositorio ya tiene su proyecto Oracle en una carpeta (por ejemplo `medidas/`, con `medidas/oracle.json`), `"oracle": "medidas"` en `.factory/config.json` le dice a Factory dónde está: los requisitos se importan en `medidas/requisitos/`, los catálogos son los de `medidas/catalogos/` y Oracle corre con ese proyecto. `oracle-factory init --oracle medidas` lo adopta al inicializar, sin crear `oracle.json` ni catálogos en la raíz. Las tareas, `openspec/` y `.factory/` siguen en la raíz. Una carpeta absoluta, con `..`, o sin `oracle.json` se rechaza.
- **Escalares del proyecto:** si el proyecto Oracle tiene `escalares.py`, Oracle sólo lo ejecuta con `--confiar-escalares`. Factory lo pasa sólo si el proyecto pone `"confiar_escalares": true` en `.factory/config.json`: es ejecutar código del proyecto (Oracle lo aísla), así que lo declara quien lo mantiene.
- **Un nombre por capacidad:** `capacidades` en `.factory/config.json` declara alias (`{"estructura2": "estructura"}`); un cambio con un alias se fusiona en la capacidad de destino, y `nuevo` lo avisa.
- **Los cambios cerrados antes de esto** se archivan con `oracle-factory archivar`, en el orden en que se cerraron; correrlo de nuevo no cambia nada.
- La spec consolidada que generó Factory (la que tiene índice en `.factory/specs/<capacidad>.json`) queda fuera de la huella del producto, como `.factory/`: se deriva de specs ya aceptadas, y si contara, archivar los cambios anteriores vencería la revisión del último cambio integrado. Cualquier otro archivo de `openspec/specs/` sí cuenta.
- **Un cambio abandonado** (`oracle-factory abandonar ID`, decidido por una persona con motivo) no fusiona nada: su spec queda en `openspec/changes/ID/` y sus `.requisito` salen de `requisitos/`, listados en el registro. El resumen lo pone en «Cambios abandonados» y no lo cuenta entre los abiertos.
- **Si se corta:** `cerrar` cierra primero y fusiona después. Un corte antes de cerrar no deja nada fusionado y se reintenta; uno después deja el cambio cerrado sin archivar, y `oracle-factory archivar` lo completa.

## El estado actual en una lectura

`oracle-factory resumen` escribe `.factory/resumen.md`: los requisitos vigentes de cada capacidad (con su tipo, su requisito de Oracle, sus medidas, el cambio del que vienen y el veredicto con que se cerró ese cambio), los cambios abiertos con lo que les falta (y las carpetas de cambio sin registro), los riesgos que aceptó una persona y los límites declarados en las revisiones, separando los de cambios que todavía tienen requisitos vigentes de los históricos. No copia los escenarios: enlaza la spec consolidada de cada capacidad.

- **Se lee con formato** con `oracle-factory resumen --ver`, que lo regenera y lo muestra con `glow` si está instalado (si no, como texto).
- **El veredicto es el del cierre**, con su fecha; no es una corrida nueva de Oracle.
- **Se regenera solo** al cerrar y al archivar. `oracle-factory resumen --verificar` dice, sin escribir, si falta o quedó viejo (por ejemplo, porque un cambio abierto avanzó o un commit venció una revisión): las mismas entradas dan siempre los mismos bytes, así que verificar es regenerar y comparar.
- **Una revisión ilegible se avisa:** si el informe o las decisiones de un cambio cerrado faltan o no se pueden leer, el resumen lo marca con ⚠ en vez de mostrarlo sin riesgos ni límites. Si el resumen no se puede generar al cerrar, el cierre igual se completa y se avisa.
- **No vence ninguna revisión:** vive en `.factory/`, fuera de la huella. `--salida RUTA` lo escribe en otro lugar del proyecto (por ejemplo `RESUMEN.md`); fuera de `.factory/`, ese archivo sí cuenta en la huella.

## Migrar un proyecto anterior (fase 2)

Hasta la fase 2, el estado de cada cambio (`factory.json`, `review.md`, `oracle-veredicto.txt`) vivía en `openspec/changes/<ID>/` y la configuración en un `factory.json` de la raíz. Un proyecto así **sigue funcionando**: Factory lee y escribe el estado donde está y avisa por la salida de error que existe `migrar`. Nada se mueve solo.

```text
oracle-factory migrar --verificar    # lista lo que movería, no escribe; falla mientras haya algo por migrar
oracle-factory migrar                # lo mueve; no hace commits
```

`migrar` escribe lo nuevo antes de borrar lo viejo y el registro al final, y en el registro sólo reescribe las rutas que citan `review.md` y `oracle-veredicto.txt`; el resto queda byte a byte. Si lo cortan, se vuelve a correr. Si un cambio tiene el estado en los dos lugares con contenido distinto, o si algo del camino es un enlace simbólico, avisa, no toca ese cambio y termina con código distinto de cero. Lo que no sabe mover (una carpeta de cambio sin registro, un `factory.json` de la raíz que no es la configuración de Factory) lo deja donde está y lo avisa, pero no es un fallo: la segunda ejecución da 0. Después de migrar, `estado` dice lo mismo y las revisiones siguen vigentes, porque la huella del producto no incluye `.factory/`. La excepción es la configuración de la raíz: es parte del producto, y moverla cambia la huella (`--verificar` lo avisa antes).

## Límites declarados

- **`tareas/` y su evidencia no se mueven**: la evidencia anterior a la estructura sigue en `tareas/<ID>/evidencia-*` y `donde` la lista como histórica.
- **`migrar` no juzga el contenido de la configuración**: mueve el `factory.json` de la raíz si sus claves son las de Factory, aunque un valor sea inválido; `config_proyecto` lo rechaza igual en el lugar nuevo, como antes en la raíz.
- **`migrar` no se defiende de otro proceso que cree enlaces mientras corre**: borra el nombre del temporal y lo abre sin seguir enlaces, pero no se prueba con concurrencia.
- **Sólo Linux, probado.** No se probó en Windows ni con otras versiones de Python que la del entorno de desarrollo.
- **`.factory/` entera queda fuera de la huella del producto**, por decisión de la spec: lo que Factory produce (evidencia, paquetes, informes) no invalida una revisión. Otra herramienta que use una carpeta `.factory` en el mismo proyecto se tomaría como propia; la carpeta personal y los enlaces simbólicos nunca cuentan como raíz.
- **`buscar` y `donde` no rechazan un enlace simbólico en otro lugar** (por ejemplo `openspec/` o `tareas/` enlazados): son de sólo lectura y el enlace lo puso quien trabaja en el proyecto. Sí rechazan que `.factory` sea un enlace.

## Salidas en JSON

`estado`, `donde` y `resumen` aceptan `--json` para que un IDE, un panel o un agente lean lo mismo que una persona, sin parsear texto. Cada objeto trae `esquema` (`oracle-factory.estado/1`, `oracle-factory.donde/1`, `oracle-factory.resumen/1`); el número sube sólo si se quita una clave o cambia su sentido, no al sumar claves. Las claves van en español, como en `factory.json`, y salen ordenadas.

- `estado ID --json`: fase, modo, `candidato` vigente (o null), `requisitos` con sus `medidas`, la `decision` que las respalda y la `propuesta` pendiente, `pendientes`, `proximo_paso` y sus `alternativas` (otros comandos que también valen; casi siempre vacía), `decisiones` (spec, revisión, cierre, abandono: actor, tipo de actor, forma, modo, cuándo, motivo), `revision` y `oracle` con el `head` al que se refieren y si siguen `vigente`s para el producto actual, `aceptados` y `avisos`. No ofrece ejecutar el próximo paso ni pregunta nada.
- `donde ID --json`: `artefactos`, cada uno con `gate`, `ruta`, `situacion` (`existe`, `ausente`, `historico` o `no_valido`) y `nota`.
- `resumen --json`: `capacidades` con sus requisitos vigentes (requisito de Oracle, tipo, medidas, veredicto al cerrar, cambio de origen), `abiertos` con sus pendientes, `abandonados`, `sin_registro`, `riesgos_aceptados`, `limites` y `problemas`. No escribe `.factory/resumen.md`; las mismas entradas dan los mismos bytes.

Con `--json`, un error va a stderr con código 1 y stdout queda vacío: un cliente nunca lee un JSON a medias. Decidir (aprobar, revisar, cerrar) sigue siendo de una persona en su terminal.
