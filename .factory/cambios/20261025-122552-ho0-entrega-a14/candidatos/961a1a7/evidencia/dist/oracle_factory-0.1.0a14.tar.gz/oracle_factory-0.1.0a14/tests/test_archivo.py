"""Archivar al cerrar: la spec de cada cambio se fusiona en openspec/specs/; escenarios a1–a6 de la spec."""
import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from oracle_factory import archivo
from oracle_factory import cli as f

GIT = ['git', '-c', 'user.name=Persona fixture', '-c', 'user.email=fixture@example.invalid', '-c', 'core.hooksPath=/dev/null',
       '-c', 'gc.auto=0', '-c', 'maintenance.auto=false']
MODIFICA = '''# Capability: notas

## MODIFIED Requirements

### Requirement: titulo valido
Tipo: funcional
The system SHALL reject titles longer than 80 characters as well as empty ones.

#### Scenario: título largo
- WHEN el título tiene 81 caracteres
- THEN no se puede guardar la nota
'''
QUITA = '''# Capability: notas

## REMOVED Requirements

### Requirement: titulo valido
Ya no aplica.

## ADDED Requirements

### Requirement: nota con fecha
Tipo: funcional
The system SHALL record the creation date of each note.

#### Scenario: nota nueva
- WHEN se guarda una nota
- THEN tiene fecha de creación
'''


class Archivo(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'producto'
        self.root.mkdir()
        for name, value in [('ROOT', self.root), ('CHANGES', self.root / 'openspec/changes'), ('AGENTE', None)]:
            p = patch.object(f, name, value); p.start(); self.addCleanup(p.stop)
        p = patch.object(f, 'terminal_interactiva', return_value=True); p.start(); self.addCleanup(p.stop)
        self.stdout = io.StringIO()
        p = contextlib.redirect_stdout(self.stdout); p.__enter__(); self.addCleanup(p.__exit__, None, None, None)
        f.inicializar()
        subprocess.run(['git', 'init', '-q', '-b', 'main'], cwd=self.root, check=True)

    # --- ayudantes -----------------------------------------------------------------
    def escribe(self, frase):
        return patch('builtins.input', return_value=frase)

    def git(self, *args):
        return subprocess.run([*GIT, *args], cwd=self.root, check=True, capture_output=True, text=True).stdout.strip()

    def salida(self):
        texto = self.stdout.getvalue()
        self.stdout.truncate(0); self.stdout.seek(0)
        return texto

    def cambio_cerrado(self):
        """El ejemplo de notas recorrido de punta a punta y cerrado por una persona."""
        ident = f.nuevo('Nota', con_ejemplo='notas')
        with self.escribe('1'):
            f.aprobar_spec(ident)
        f.importar(ident)
        rid = f.leer(ident)[1]['requisitos'][0]
        f.medir(ident, requisito_id=rid, medidas=['notas.casos_ejecutados', 'notas.resultados'], quitar_sin_medir=True)
        self.git('add', '.')
        self.git('commit', '-qm', 'producto fixture')
        informe = self.root / 'tareas' / ident / 'revision.md'
        informe.write_text('Fixture de revisión; no es una revisión real.\n')
        with self.escribe('1'):
            f.revisar(ident, informe, 'Persona fixture', 'aprobar', 0)
        hechos = self.root / 'tareas' / ident / 'hechos.json'
        subprocess.run([sys.executable, 'examples/notas/sensor.py', '--salida', hechos], cwd=self.root, check=True, capture_output=True)
        f.juzgar(ident, hechos)
        with self.escribe('1'):
            f.cerrar(ident)
        return ident

    def cambio_importado(self, titulo, capacidad, spec):
        """Un cambio con la spec dada, aceptada e importada (sin el recorrido de medidas, revisión y juicio)."""
        ident = f.nuevo(titulo, capacidad)
        carpeta, estado = f.leer(ident)
        (self.root / estado['spec']).write_text(spec, encoding='utf-8')
        (carpeta / 'proposal.md').write_text(f'# {titulo}\n\nFixture.\n', encoding='utf-8')
        with self.escribe('1'):
            f.aprobar_spec(ident)
        f.importar(ident)
        return ident

    def marcar_cerrado(self, ident, cuando):
        """Cierra el registro sin el recorrido completo: archivar sólo mira la fase y el orden de cierre."""
        carpeta, estado = f.leer(ident)
        estado.update(fase='cerrada', cierre={'actor': 'Persona fixture', 'tipo_actor': 'persona', 'forma': 'decidio', 'modo': 'confirmacion',
                                              'cuando': cuando})
        f.guardar(carpeta, estado)

    def consolidada(self, capacidad='notas'):
        return (self.root / 'openspec/specs' / capacidad / 'spec.md').read_text(encoding='utf-8')

    def archivos(self):
        return {str(p.relative_to(self.root)): p.read_bytes() for p in sorted(self.root.rglob('*'))
                if p.is_file() and '.git' not in p.relative_to(self.root).parts}

    # --- a1: la spec de un cambio se fusiona al cerrarlo -------------------------------------------------------
    def test_a1_primer_cambio_de_una_capacidad(self):
        ident = self.cambio_cerrado()
        estado = f.leer(ident)[1]
        texto = self.consolidada()
        self.assertIn('### Requirement: titulo valido', texto)
        self.assertIn(f'Origen: {ident} · {estado["requisitos"][0]}', texto)
        self.assertIn('#### Scenario: título vacío', texto)
        self.assertEqual(estado['archivo']['spec'], 'openspec/specs/notas/spec.md')
        self.assertEqual([e['accion'] for e in estado['eventos']][-2:], ['cierre', 'archivado'])

    def test_a1_un_cambio_que_modifica_y_quita_requisitos(self):
        primero = self.cambio_cerrado()
        modifica = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        self.marcar_cerrado(modifica, '2099-01-01T00:00:00+00:00')
        f.archivar()
        texto = self.consolidada()
        self.assertIn('longer than 80 characters', texto)
        self.assertIn(f'Origen: {modifica} ·', texto)
        self.assertNotIn('whitespace-only', texto)  # el texto viejo ya no está
        quita = self.cambio_importado('Fechas', 'notas', QUITA)
        self.marcar_cerrado(quita, '2099-01-02T00:00:00+00:00')
        f.archivar()
        texto = self.consolidada()
        self.assertNotIn('titulo valido', texto)
        self.assertIn('### Requirement: nota con fecha', texto)
        self.assertTrue(primero)

    # --- a2: un conflicto impide cerrar --------------------------------------------------------------------------
    def test_a2_agregar_un_requisito_que_ya_existe(self):
        self.cambio_cerrado()
        repetido = self.cambio_importado('Otra vez', 'notas', (self.root / 'examples/notas/spec.md').read_text())
        antes = self.archivos()
        with patch.object(f, 'pendientes_actuales', return_value=[]), self.escribe('1'), \
                self.assertRaises(f.FactoryError) as error:
            f.cerrar(repetido)
        self.assertIn('titulo valido', str(error.exception))
        self.assertEqual(self.archivos(), antes)  # ni el registro ni la spec consolidada cambiaron
        self.assertNotEqual(f.leer(repetido)[1]['fase'], 'cerrada')

    def test_a2_modificar_un_requisito_que_no_existe(self):
        ident = self.cambio_importado('Sin base', 'notas', MODIFICA)
        self.marcar_cerrado(ident, '2099-01-01T00:00:00+00:00')
        antes = self.archivos()
        with self.assertRaises(f.FactoryError) as error:
            f.archivar()
        self.assertIn('no existe', str(error.exception))
        self.assertEqual(self.archivos(), antes)

    def test_a2_una_spec_consolidada_editada_a_mano_no_se_pisa(self):
        self.cambio_cerrado()
        consolidada = self.root / 'openspec/specs/notas/spec.md'
        consolidada.write_text(consolidada.read_text() + '\n### Requirement: agregado a mano\nNadie lo aprobó.\n')
        ident = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        self.marcar_cerrado(ident, '2099-01-01T00:00:00+00:00')
        antes = self.archivos()
        with self.assertRaises(f.FactoryError) as error:
            f.archivar()
        self.assertIn('editó a mano', str(error.exception))
        self.assertEqual(self.archivos(), antes)

    def test_a2_cerrar_con_la_spec_consolidada_editada_se_rechaza_antes_de_preguntar(self):
        self.cambio_cerrado()
        consolidada = self.root / 'openspec/specs/notas/spec.md'
        consolidada.write_text(consolidada.read_text() + '\nagregado a mano\n')
        ident = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        antes = self.archivos()
        with patch.object(f, 'pendientes_actuales', return_value=[]), \
                patch('builtins.input', side_effect=AssertionError('no debía preguntar')), self.assertRaises(f.FactoryError) as error:
            f.cerrar(ident)
        self.assertIn('editó a mano', str(error.exception))
        self.assertEqual(self.archivos(), antes)  # ni la tarea ni el registro se cerraron
        self.assertNotEqual(f.leer(ident)[1]['fase'], 'cerrada')

    def test_a2_secciones_mayusculas_y_nombres_repetidos(self):
        self.cambio_cerrado()
        minusculas = MODIFICA.replace('## MODIFIED Requirements', '## Modified Requirements') + '\n### Notas internas\nNo es un requisito.\n'
        ident = self.cambio_importado('Títulos largos', 'notas', minusculas)
        self.marcar_cerrado(ident, '2099-01-01T00:00:00+00:00')
        f.archivar()  # «Modified» es MODIFIED: no choca con el requisito que ya existe
        texto = self.consolidada()
        self.assertIn('longer than 80 characters', texto)
        self.assertNotIn('No es un requisito.', texto)  # otra sección ### cierra el requisito
        # Oracle ya rechaza al importar una spec con un nombre repetido; la fusión tampoco lo acepta
        repetida = QUITA.split('Ya no aplica.\n\n')[1] * 2
        with self.assertRaises(archivo.Conflicto) as error:
            archivo.fusionar(archivo.indice_vacio('otra'), repetida, 'c', {'nota_con_fecha': 'otra_c.nota_con_fecha'})
        self.assertIn('más de una vez', str(error.exception))

    # --- a3: lo cerrado no se mueve ni se reescribe ---------------------------------------------------------------
    def test_a3_archivar_solo_agrega_la_marca(self):
        primero = self.cambio_cerrado()
        otro = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        self.marcar_cerrado(otro, '2099-01-01T00:00:00+00:00')
        antes = self.archivos()
        estado_primero = f.leer(primero)[1]
        f.archivar()
        despues = self.archivos()
        cambiados = {k for k in set(antes) | set(despues) if antes.get(k) != despues.get(k)}
        self.assertEqual(cambiados, {f'.factory/cambios/{otro}/factory.json', 'openspec/specs/notas/spec.md',
                                     '.factory/specs/notas.json', '.factory/resumen.md'})  # el resumen se regenera
        self.assertEqual(f.leer(primero)[1], estado_primero)  # el cambio anterior no se tocó
        nuevo = f.leer(otro)[1]
        self.assertEqual(nuevo['eventos'][-1]['accion'], 'archivado')

    def test_a3_un_corte_al_guardar_el_registro_no_lo_trunca(self):
        ident = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        carpeta, estado = f.leer(ident)
        antes = f.ruta_registro(carpeta).read_bytes()
        estado['titulo'] = 'otro'
        with patch.object(f.os, 'replace', side_effect=OSError('disco lleno')), self.assertRaises(OSError):
            f.guardar(carpeta, estado)
        self.assertEqual(f.ruta_registro(carpeta).read_bytes(), antes)  # entero, no a medias

    def test_a3_un_registro_de_solo_lectura_no_se_modifica(self):
        ident = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        carpeta, estado = f.leer(ident)
        registro = f.ruta_registro(carpeta)
        antes = registro.read_bytes()
        registro.chmod(0o444)
        self.addCleanup(registro.chmod, 0o644)
        estado['titulo'] = 'otro'
        with self.assertRaises(f.FactoryError):
            f.guardar(carpeta, estado)
        self.assertEqual(registro.read_bytes(), antes)

    # --- a4: se distingue lo vigente de lo reemplazado --------------------------------------------------------------
    def test_a4_requisito_reemplazado(self):
        primero = self.cambio_cerrado()
        modifica = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        self.marcar_cerrado(modifica, '2099-01-01T00:00:00+00:00')
        f.archivar()
        self.salida()
        f.mostrar(primero)
        rid = f.leer(primero)[1]['requisitos'][0]
        self.assertIn(f'{rid}: reemplazado por {modifica}', self.salida())
        f.mostrar(modifica)
        self.assertIn(f'{f.leer(modifica)[1]["requisitos"][0]}: vigente', self.salida())

    # --- a5: una capacidad con un solo nombre -----------------------------------------------------------------------
    def test_a5_capacidad_con_alias(self):
        config = self.root / '.factory/config.json'
        config.write_text(json.dumps({'capacidades': {'notas2': 'notas'}}))
        self.cambio_cerrado()
        errores = io.StringIO()
        with contextlib.redirect_stderr(errores):
            ident = self.cambio_importado('Fechas', 'notas2', QUITA.replace('Capability: notas', 'Capability: notas2'))
        self.assertIn('alias de notas', errores.getvalue())
        self.marcar_cerrado(ident, '2099-01-01T00:00:00+00:00')
        f.archivar()
        self.assertIn('### Requirement: nota con fecha', self.consolidada())
        self.assertFalse((self.root / 'openspec/specs/notas2').exists())

    def test_a5_un_alias_de_un_alias_se_rechaza(self):
        (self.root / '.factory/config.json').write_text(json.dumps({'capacidades': {'a': 'b', 'b': 'c'}}))
        with self.assertRaises(f.FactoryError):
            f.config_proyecto()

    # --- a6: archivar es repetible y los comandos de lectura lo muestran -----------------------------------------------
    def test_a6_segunda_ejecucion_no_cambia_nada(self):
        self.cambio_cerrado()
        ident = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        self.marcar_cerrado(ident, '2099-01-01T00:00:00+00:00')
        f.archivar()
        antes = self.archivos()
        self.salida()
        f.archivar()
        self.assertIn('No hay cambios cerrados sin archivar', self.salida())
        self.assertEqual(self.archivos(), antes)

    def test_a6_reintento_de_un_cierre_cortado_no_duplica(self):
        real = f.ejecutar

        def falla_al_cerrar_la_tarea(argv, *a, **k):
            if argv[:2] == ['tasks', 'close']:
                return subprocess.CompletedProcess(argv, 1, '', 'tracker no disponible')
            return real(argv, *a, **k)

        with patch.object(f, 'ejecutar', falla_al_cerrar_la_tarea), self.assertRaises(f.FactoryError):
            self.cambio_cerrado()  # el cierre no se completó
        self.assertFalse((self.root / 'openspec/specs/notas').exists())  # y nada quedó fusionado
        ident = f.leer(sorted(p.name for p in (self.root / 'openspec/changes').iterdir() if p.is_dir())[0])[1]['id']
        with self.escribe('1'):
            f.cerrar(ident)  # el reintento no choca con su propia fusión
        self.assertEqual(self.consolidada().count('### Requirement: titulo valido'), 1)
        self.assertEqual(f.leer(ident)[1]['fase'], 'cerrada')

    def test_a6_solo_se_archivan_los_cerrados_y_en_el_orden_de_cierre(self):
        self.cambio_cerrado()
        quita = self.cambio_importado('Fechas', 'notas', QUITA)  # creado antes, cerrado después
        modifica = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        abierto = self.cambio_importado('Abierto', 'otra', '# Capability: otra\n\n' + QUITA.split('Ya no aplica.\n\n')[1])
        self.marcar_cerrado(modifica, '2099-01-01T00:00:00+00:00')
        self.marcar_cerrado(quita, '2099-01-02T00:00:00+00:00')
        f.archivar()  # en orden de creación chocaría: quitar «titulo valido» y después modificarlo
        self.assertIn('### Requirement: nota con fecha', self.consolidada())
        self.assertNotIn('archivo', f.leer(abierto)[1])
        self.assertFalse((self.root / 'openspec/specs/otra').exists())

    def test_a6_un_corte_entre_la_spec_y_el_indice_se_repara(self):
        self.cambio_cerrado()
        ident = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        self.marcar_cerrado(ident, '2099-01-01T00:00:00+00:00')
        real = f.escribir_atomico

        def corta_antes_del_indice(ruta, datos, **k):
            if ruta.suffix == '.json' and ruta.parent.name == 'specs':
                raise KeyboardInterrupt
            return real(ruta, datos, **k)

        with patch.object(f, 'escribir_atomico', corta_antes_del_indice), self.assertRaises(KeyboardInterrupt):
            f.archivar()
        self.assertIn('longer than 80 characters', self.consolidada())  # la spec ya se escribió; el índice no
        f.archivar()  # el reintento la reconoce como suya y completa el índice y la marca
        self.assertEqual(f.leer(ident)[1]['archivo']['capacidad'], 'notas')
        indice = json.loads((self.root / '.factory/specs/notas.json').read_text())
        self.assertIn(ident, indice['archivados'])

    def test_a6_un_cierre_anterior_sin_registro_de_cierre(self):
        self.cambio_cerrado()
        ident = self.cambio_importado('Títulos largos', 'notas', MODIFICA)
        carpeta, estado = f.leer(ident)
        estado['fase'] = 'cerrada'  # como los cierres de antes de los modos: sólo el evento
        estado['eventos'].append({'accion': 'cierre', 'cuando': '2099-01-01T00:00:00+00:00'})
        f.guardar(carpeta, estado)
        f.archivar()
        self.assertIn('longer than 80 characters', self.consolidada())

    def test_a6_la_huella_ignora_solo_las_specs_que_genera_factory(self):
        self.cambio_cerrado()
        self.git('add', '.')
        self.git('commit', '-qm', 'cerrado')
        huella = f.contexto_producto()['archivos_sha256']
        ajena = self.root / 'openspec/specs/escrita-a-mano/spec.md'
        ajena.parent.mkdir(parents=True)
        ajena.write_text('# a mano\n')
        self.assertNotEqual(f.contexto_producto()['archivos_sha256'], huella)  # la que no generó Factory es producto
        ajena.unlink()
        self.assertEqual(f.contexto_producto()['archivos_sha256'], huella)

    def test_a6_lectura_de_un_cambio_archivado(self):
        ident = self.cambio_cerrado()
        self.salida()
        f.listar(None, False, False)
        self.assertRegex(self.salida(), rf'{ident}  cerrada \(archivado\)')
        f.comando_donde(ident, None)
        self.assertRegex(self.salida(), r'(?m)^archivo\s+existe\s+openspec/specs/notas/spec\.md')
        f.comando_buscar('whitespace-only', 50)
        self.assertIn('openspec/specs/notas/spec.md', self.salida())


if __name__ == '__main__':
    unittest.main()
